# A/B Test Analysis for an E-Commerce Website

## Project objective
Compare the existing pricing/landing page (control) with the new page (treatment) and test whether the new page improves conversion.

## Files
- `ab_data.csv` — raw experiment data (user, timestamp, group, page, conversion)
- `countries.csv` — user-to-country mapping
- `AB_Test_Pricing_Report.pdf` — supplied corrected report
- `analysis.py` — end-to-end reproducible analysis
- `AB_Test_Analysis.ipynb` — notebook version of the analysis
- `requirements.txt` — Python dependencies
- `outputs/` — generated cleaned data and charts after running the analysis

## Run locally (Windows / VS Code)
1. Install Python 3.10+.
2. Open this folder in VS Code.
3. In the terminal, run:
   ```bash
   python -m venv .venv
   .venv\Scripts\activate
   pip install -r requirements.txt
   python analysis.py
   ```
4. Open `AB_Test_Analysis.ipynb` in VS Code/Jupyter and run cells from top to bottom.

## Cleaning approach
Rows where `group` and `landing_page` conflict are removed. Duplicate `user_id` records are reduced to the first remaining record. The cleaned data is joined to the country file using a one-to-one inner join. The script prints actual computed results, exports the cleaned data, and saves charts.

## Statistical methods
- Welch independent two-sample t-test on the binary conversion indicator (its mean is the conversion rate)
- Chi-square test of independence for group versus conversion
- One-way ANOVA across countries and across country × strategy groups
- Approximate 95% confidence interval for the treatment-minus-control conversion-rate difference

Significance threshold: α = 0.05. A p-value above 0.05 means the experiment does not provide sufficient evidence of a difference; it does not prove the pages are identical.

## Report-level takeaway
The supplied report concludes that the control page converts at about 12.04% and the treatment page at about 11.88%; reported p-values are approximately 0.19. Its recommendation is to retain the existing page unless a more targeted follow-up experiment provides stronger evidence.
