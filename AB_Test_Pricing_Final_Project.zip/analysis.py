"""
A/B Test Analysis for an E-Commerce Website
Run: python analysis.py
"""
from pathlib import Path
import pandas as pd
import numpy as np
from scipy import stats
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "outputs"
OUT.mkdir(exist_ok=True)

ab = pd.read_csv(ROOT / "ab_data.csv")
countries = pd.read_csv(ROOT / "countries.csv")

# Keep only rows where assigned group and page are consistent.
valid = (
    ((ab["group"] == "control") & (ab["landing_page"] == "old_page")) |
    ((ab["group"] == "treatment") & (ab["landing_page"] == "new_page"))
)
clean = ab.loc[valid].drop_duplicates(subset="user_id", keep="first").copy()
clean = clean.merge(countries, on="user_id", how="inner", validate="one_to_one")
clean["converted"] = pd.to_numeric(clean["converted"], errors="coerce")
clean = clean.dropna(subset=["converted", "group", "country"])
clean["converted"] = clean["converted"].astype(int)
clean.to_csv(OUT / "cleaned_ab_data.csv", index=False)

summary = clean.groupby("group")["converted"].agg(["count", "sum", "mean"])
summary["conversion_rate_pct"] = summary["mean"] * 100
print("\nGROUP SUMMARY\n", summary.to_string())
control = clean.loc[clean.group == "control", "converted"]
treatment = clean.loc[clean.group == "treatment", "converted"]
t_stat, t_p = stats.ttest_ind(treatment, control, equal_var=False)
contingency = pd.crosstab(clean["group"], clean["converted"]).reindex(
    index=["control", "treatment"], columns=[0, 1], fill_value=0
)
chi2, chi_p, dof, expected = stats.chi2_contingency(contingency)

diff = treatment.mean() - control.mean()
se = np.sqrt(treatment.var(ddof=1)/len(treatment) + control.var(ddof=1)/len(control))
ci_low, ci_high = diff - 1.96*se, diff + 1.96*se

print(f"\nWelch t-test: t={t_stat:.4f}, p={t_p:.4f}")
print(f"Chi-square: chi2={chi2:.4f}, df={dof}, p={chi_p:.4f}")
print(f"Treatment-control difference: {diff*100:.3f} percentage points")
print(f"Approx. 95% CI: [{ci_low*100:.3f}, {ci_high*100:.3f}] percentage points")

country_rates = clean.groupby("country")["converted"].mean().sort_index()
country_groups = [g["converted"].to_numpy() for _, g in clean.groupby("country")]
f_country, p_country = stats.f_oneway(*country_groups)
six_groups = [g["converted"].to_numpy() for _, g in clean.groupby(["country", "group"])]
f_six, p_six = stats.f_oneway(*six_groups)
print("\nCOUNTRY CONVERSION RATES (%)\n", (country_rates*100).round(3).to_string())
print(f"ANOVA across countries: F={f_country:.4f}, p={p_country:.4f}")
print(f"ANOVA across country × strategy groups: F={f_six:.4f}, p={p_six:.4f}")

# Visualizations
rates = clean.groupby("group")["converted"].mean().reindex(["control", "treatment"])
counts = clean.groupby("group")["converted"].size().reindex(["control", "treatment"])
errors = 1.96*np.sqrt(rates*(1-rates)/counts)
plt.figure(figsize=(7, 4.5))
plt.bar(["Control (old page)", "Treatment (new page)"], rates*100, yerr=errors*100, capsize=5)
plt.ylabel("Conversion rate (%)")
plt.title("Conversion Rate by Pricing Strategy (95% approximate CI)")
plt.tight_layout()
plt.savefig(OUT / "conversion_by_strategy.png", dpi=180)
plt.close()

ct = clean.groupby(["country", "group"])["converted"].mean().unstack()
ct = ct.reindex(["CA", "UK", "US"])
ct.plot(kind="bar", figsize=(8, 4.5))
plt.ylabel("Conversion rate")
plt.xlabel("Country")
plt.title("Conversion Rate by Country and Strategy")
plt.xticks(rotation=0)
plt.tight_layout()
plt.savefig(OUT / "conversion_by_country_strategy.png", dpi=180)
plt.close()

print(f"\nSaved cleaned data and charts in: {OUT}")
print("Decision at alpha=0.05:", "statistically significant difference" if t_p < 0.05 else "no statistically significant difference")
